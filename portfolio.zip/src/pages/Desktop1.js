const Desktop1 = () => {
  return (
    <div className="relative bg-white w-full h-[3851px] overflow-hidden text-left text-6xl text-black font-barlow">
      <div className="absolute top-[1801px] left-[0px] bg-floralwhite w-[1440px] h-[823px]" />
      <div className="absolute top-[1077px] left-[621px] rounded-31xl bg-white shadow-[40px_20px_20px_rgba(0,_0,_0,_0.02)] w-[701px] h-[655px]" />
      <div className="absolute top-[0px] left-[0px] bg-floralwhite w-[1440px] h-[1024px]" />
      <div className="absolute top-[346px] left-[1110px] inline-block w-[233px] h-24 text-14xl">
        <p className="m-0">
          <span className="font-semibold">
            <span>
              <span className="text-darkslategray">Tools</span>
            </span>
          </span>
          <span>
            <span className="font-semibold">
              <span>{` `}</span>
            </span>
          </span>
        </p>
        <p className="m-0 text-4xl">
          <span>
            <span className="font-semibold">
              <span className="text-xl">{`on which `}</span>
            </span>
            <span className="font-medium">I have worked upon</span>
          </span>
        </p>
      </div>
      <div className="absolute top-[42px] left-[112px] text-[50px] font-extrabold font-open-sans inline-block w-[89px] h-[65px]">
        <span>ay</span>
        <span className="text-darkslategray">.</span>
      </div>
      <div className="absolute top-[61px] left-[1150px] w-[179px] h-11 text-base">
        <div className="absolute top-[13px] left-[0px] inline-block w-[108px] h-[18px]">
          +91 9311280283
        </div>
        <div className="absolute top-[0px] left-[137px] rounded-[50%] bg-white shadow-[0px_4px_24px_rgba(0,_0,_0,_0.1)] w-[42px] h-11" />
        <img
          className="absolute h-[32.64%] w-[8.38%] top-[34.09%] right-[7.82%] bottom-[33.27%] left-[83.8%] max-w-full overflow-hidden max-h-full"
          alt=""
          src="/call.svg"
        />
      </div>
      <div className="absolute top-[62px] left-[496px] w-[469px] h-[42px] text-base">
        <div className="absolute top-[12px] left-[125px] font-medium inline-block w-[94px] h-[18px]">
          EXPERIENCE
        </div>
        <div className="absolute top-[12px] left-[250px] font-medium inline-block w-[94px] h-[18px]">
          PROJECTS
        </div>
        <div className="absolute top-[12px] left-[0px] font-medium inline-block w-[94px] h-[18px]">
          EDUCATION
        </div>
        <div className="absolute top-[12px] left-[375px] font-medium inline-block w-[94px] h-[18px]">
          CONTACT ME
        </div>
        <div className="absolute top-[0px] left-[110px] rounded-31xl box-border w-[124px] h-[42px] border-[1px] border-solid border-darkslategray" />
      </div>
      <div className="absolute top-[701px] left-[112px] inline-block w-[190px] h-[71px] text-14xl text-darkslategray">
        <p className="m-0">
          <span className="font-semibold">
            <span>
              <span>Languages</span>
              <span>{` `}</span>
            </span>
          </span>
        </p>
        <p className="m-0 text-4xl text-black">
          <span>
            <span className="font-medium">I know</span>
          </span>
        </p>
      </div>
      <div className="absolute top-[784px] left-[112px] font-medium inline-block w-[247px] h-[159px]">
        C/C++, Python, SQL, HTML, JavaScript, CSS, Mongoose, Express, Node
      </div>
      <div className="absolute top-[455px] left-[1110px] font-medium whitespace-pre-wrap inline-block w-[233px] h-[159px]">
        <p className="m-0">
          Matlab, Figma, Oracle Live SQl, Arduino IDE, GIT, TinkerCAD,
        </p>
        <p className="m-0">AutoCAD</p>
      </div>
      <img
        className="absolute top-[205px] left-[396px] w-[675px] h-[819px] object-cover"
        alt=""
        src="/untitled-design-2-1@2x.png"
      />
      <div className="absolute top-[205px] left-[112px] text-71xl font-medium inline-block w-[455px] h-[231px]">
        <p className="m-0">Hey There,</p>
        <p className="m-0">I’m Aastik</p>
      </div>
      <img
        className="absolute top-[334px] left-[496px] w-[476px] h-[648px] object-cover"
        alt=""
        src="/img20230401141656--1-removebgpreview-1@2x.png"
      />
      <img
        className="absolute top-[1157px] left-[649px] w-[133.86px] h-[100px] object-cover"
        alt=""
        src="/thapar-institute-of-engineering-and-technology-university-logoremovebgpreview-1@2x.png"
      />
      <div className="absolute top-[1162px] left-[783px] whitespace-pre-wrap inline-block w-[521px] h-[233px]">
        <p className="m-0">
          <span>
            <span>Thapar Institute of Engineering and Technology  </span>
            <span className="text-xl">Patiala, Punjab</span>
          </span>
        </p>
        <p className="m-0">
          <span className="font-medium">
            <span>&nbsp;</span>
          </span>
        </p>
        <p className="m-0 text-8xl">
          <span>
            <span className="font-medium">
              Electrical and Computer Engineering
            </span>
          </span>
        </p>
        <p className="m-0">
          <span>
            <span className="font-barlow">cgpa-</span>
            <span className="font-medium">{` 8.69   `}</span>
          </span>
        </p>
      </div>
      <div className="absolute top-[1280px] left-[1044px] font-medium inline-block w-[139px] h-[25px]">
        2020-2024
      </div>
      <div className="absolute top-[1434px] left-[783px] whitespace-pre-wrap inline-block w-[300px] h-[237px]">
        <p className="m-0">
          <span>
            <span>DAV Public School, Sec - 14 </span>
            <span className="text-xl">Gurgaon, Haryana</span>
          </span>
        </p>
        <p className="m-0">
          <span className="font-medium">
            <span>&nbsp;</span>
          </span>
        </p>
        <p className="m-0 text-8xl">
          <span>
            <span className="font-medium">Class XII</span>
          </span>
        </p>
        <p className="m-0">
          <span>
            <span className="font-barlow">percentage-</span>
            <span className="font-medium">{` 94.8%         `}</span>
          </span>
        </p>
        <p className="m-0">
          <span className="font-medium">
            <span>&nbsp;</span>
          </span>
        </p>
        <p className="m-0 text-8xl">
          <span className="font-medium">
            <span>Class X</span>
          </span>
        </p>
        <p className="m-0">
          <span>
            <span>percentage-</span>
            <span className="font-medium font-barlow"> 92%</span>
          </span>
        </p>
      </div>
      <div className="absolute top-[1646px] left-[1044px] font-medium inline-block w-[119px] h-[25px]">
        2017-2018
      </div>
      <div className="absolute top-[1550px] left-[1044px] font-medium inline-block w-[521px] h-[27px]">
        2019-2020
      </div>
      <div className="absolute top-[1067px] left-[112px] inline-block w-[455px] h-56 text-56xl">
        <span>About my,</span>
        <span className="text-71xl font-medium"> Education</span>
      </div>
      <div className="absolute top-[1925px] left-[867px] text-right inline-block w-[455px] h-56 text-56xl">
        <span>My work,</span>
        <span className="text-71xl font-medium"> Experience</span>
      </div>
      <div className="absolute top-[2659px] left-[119px] inline-block w-[506px] h-[133px] text-71xl">
        <span>
          <span>My,</span>
          <span className="text-56xl">{` `}</span>
        </span>
        <span className="font-medium">Projects</span>
      </div>
      <img
        className="absolute top-[1430px] left-[649px] w-[130.71px] h-[120px] object-cover"
        alt=""
        src="/image-1@2x.png"
      />
      <div className="absolute top-[1965px] left-[114px] rounded-31xl bg-white shadow-[40px_20px_20px_rgba(0,_0,_0,_0.02)] w-[701px] h-[475px] text-8xl">
        <div className="absolute top-[281px] left-[219px] whitespace-pre-wrap inline-block w-[447px] h-[133px]">
          <p className="[margin-block-start:0] [margin-block-end:15px] font-semibold">
            Anar App Pvt. Ltd.
          </p>
          <p className="[margin-block-start:0] [margin-block-end:15px] text-11xl">
            <span>
              <span>Data Quality Intern</span>
              <span className="text-6xl">&nbsp;</span>
              <span className="text-xl">{`Remote   `}</span>
            </span>
          </p>
          <p className="[margin-block-start:0] [margin-block-end:15px] text-2xl font-semibold">
            Feb’22 - Mar’22
          </p>
        </div>
        <img
          className="absolute top-[281px] left-[60px] rounded-[50%] w-[100px] h-[100px] object-cover"
          alt=""
          src="/ellipse-3@2x.png"
        />
        <img
          className="absolute top-[50px] left-[60px] rounded-[50%] w-[100px] h-[100px] object-cover"
          alt=""
          src="/ellipse-4@2x.png"
        />
        <div className="absolute top-[51px] left-[219px] whitespace-pre-wrap inline-block w-[447px] h-[133px]">
          <p className="[margin-block-start:0] [margin-block-end:15px] font-semibold">
            TalentServe
          </p>
          <p className="[margin-block-start:0] [margin-block-end:15px] text-11xl">
            <span>
              <span>Marketing/ Business Development</span>
              <span className="text-6xl">&nbsp;</span>
              <span className="text-xl">{`Remote    `}</span>
            </span>
          </p>
          <p className="[margin-block-start:0] [margin-block-end:15px] text-2xl font-semibold">
            Jun’23 - Aug’23
          </p>
        </div>
        <div className="absolute top-[149.5px] left-[109.5px] box-border w-px h-[132px] border-r-[1px] border-solid border-black" />
      </div>
      <div className="absolute top-[3026px] left-[119px] rounded-21xl bg-beige shadow-[20px_30px_60px_rgba(0,_0,_0,_0.1)] w-[505.85px] h-[450px]" />
      <div className="absolute top-[3026px] left-[663px] rounded-21xl bg-beige shadow-[20px_30px_60px_rgba(0,_0,_0,_0.1)] w-[505.85px] h-[450px]" />
      <b className="absolute top-[3068px] left-[720px] text-11xl inline-block text-darkslategray w-[318px] h-[46px]">
        Stock Price Prediction
      </b>
      <div className="absolute top-[3149px] left-[720px] font-medium inline-block w-[263px] h-[46px]">{`using Python & `}</div>
      <div className="absolute top-[2709px] left-[1059px] font-medium text-firebrick inline-block w-[263px] h-[46px]">
        Explore more Projects!
      </div>
      <b className="absolute top-[3068px] left-[175px] text-11xl inline-block text-darkslategray w-[263px] h-[46px]">
        Hotstar Clone
      </b>
      <div className="absolute top-[3149px] left-[175px] font-medium inline-block w-[263px] h-[46px]">{`using CSS & JavaScript`}</div>
      <img
        className="absolute top-[3176px] left-[131px] w-[494.34px] h-[300px] object-cover"
        alt=""
        src="/screenshot-20230609-123919removebgpreview-1@2x.png"
      />
      <div className="absolute top-[3026px] left-[1207px] rounded-21xl bg-beige shadow-[20px_30px_60px_rgba(0,_0,_0,_0.1)] w-[505.85px] h-[450px]" />
      <div className="absolute top-[3666px] left-[0px] bg-floralwhite w-[1440px] h-[185px] text-base">
        <div className="absolute top-[24px] left-[131px] w-[94px] h-[120px] flex flex-col items-center justify-start gap-[16px]">
          <div className="relative font-semibold inline-block w-[94px] h-[18px] shrink-0">
            ABOUT
          </div>
          <div className="relative font-semibold inline-block w-[94px] h-[18px] shrink-0">
            EDUCATION
          </div>
          <div className="relative font-semibold inline-block w-[94px] h-[18px] shrink-0">
            EXPERIENCE
          </div>
          <div className="relative font-semibold inline-block w-[94px] h-[18px] shrink-0">
            PROJECTS
          </div>
        </div>
        <div className="absolute top-[28px] left-[767px] w-[223px] h-[131px]">
          <div className="absolute top-[0px] left-[0px] font-semibold inline-block w-[94px] h-[18px]">
            CONTACT ME
          </div>
          <div className="absolute top-[42px] left-[35px] inline-block w-[188px] h-[38px]">
            <p className="m-0">ayadav1_be20@thapar.edu</p>
            <p className="m-0">aastikyadavay@gmail.com</p>
          </div>
          <div className="absolute top-[93px] left-[35px] inline-block w-[188px] h-[38px]">
            +91 9311280283
          </div>
          <img
            className="absolute h-[10.96%] w-[6.73%] top-[73.28%] right-[93.27%] bottom-[15.75%] left-[0%] max-w-full overflow-hidden max-h-full"
            alt=""
            src="/call.svg"
          />
          <img
            className="absolute h-[9.75%] w-[7.47%] top-[38.17%] right-[92.53%] bottom-[52.09%] left-[0%] max-w-full overflow-hidden max-h-full"
            alt=""
            src="/mail.svg"
          />
        </div>
        <div className="absolute top-[106px] left-[1181px] w-[141px] h-[35px] flex flex-row items-center justify-start gap-[18px]">
          <img
            className="relative w-[35px] h-[35px] object-cover"
            alt=""
            src="/github@2x.png"
          />
          <img
            className="relative w-[35px] h-[35px] object-cover"
            alt=""
            src="/linkedin@2x.png"
          />
          <img
            className="relative w-[35px] h-[35px] object-cover"
            alt=""
            src="/discord@2x.png"
          />
        </div>
      </div>
    </div>
  );
};

export default Desktop1;
