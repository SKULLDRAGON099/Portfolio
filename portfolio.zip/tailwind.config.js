/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        white: "#fff",
        floralwhite: "#f8f7f1",
        black: "#000",
        beige: "#ededda",
        darkslategray: "#28656c",
        firebrick: "#a70d0d",
      },
      fontFamily: {
        barlow: "Barlow",
        "open-sans": "'Open Sans'",
      },
      borderRadius: {
        "21xl": "40px",
        "31xl": "50px",
      },
    },
    fontSize: {
      base: "16px",
      "6xl": "25px",
      "11xl": "30px",
      "2xl": "21px",
      xl: "20px",
      "8xl": "27px",
      "71xl": "90px",
      "56xl": "75px",
      "4xl": "23px",
      "14xl": "33px",
    },
  },
  corePlugins: {
    preflight: false,
  },
};
